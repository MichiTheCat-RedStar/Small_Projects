ListName = input("Введите название списка: ")
User0 = input("\nСлова написаны через пробел [0], запятую [1], пробел с запятой [2] или перенос [3]?\nНапишите цифру: ")
if User0 not in ["0", "1", "2", "3"]:
    print("\nВы допустили ошибку")
User1 = input("\nОставить слова [0], сделать верхний регистр [1], сделать нижний регистр [2] или сделать с большой буквы [3]?\nНапишите цифру: ")
if User1 not in ["0", "1", "2", "3"]:
    print("\nВы допустили ошибку")
User2 = input("\nУдалить ли повторяющиеся слова [N]/[Y]?\nНапишите букву: ")
if User2 not in ["N", "Y"]:
    print("\nВы допустили ошибку")
User3 = input("\nПеревернуть ли список [N]/[Y]?\nНапишите букву: ")
if User3 not in ["N", "Y"]:
    print("\nВы допустили ошибку")

Words = open("Text.txt", "r", encoding="utf-8")
if User0 == "0":
    List = Words.read().split()
elif User0 == "1":
    List = Words.read().split(",")
elif User0 == "2":
    List = Words.read().split(", ")
elif User0 == "3":
    List = Words.read().split("\n")
Words.close()

NewList = []
if User1 == "0":
    pass
elif User1 == "1":
    for i in List:
        NewList.append(i.upper())
    List = NewList
elif User1 == "2":
    for i in List:
        NewList.append(i.lower())
    List = NewList
elif User1 == "3":
    for i in List:
        NewList.append(i.title())
    List = NewList

if User2 == "N":
    pass
elif User2 == "Y":
    List = list(set(List))

if User3 == "N":
    pass
elif User3 == "Y":
    List.reverse()

List = str(f"{ListName} = {List}")
Words = open("List.txt", "w", encoding="utf-8")
Words.write(List)
Words.close()

print(f"\n{List}")