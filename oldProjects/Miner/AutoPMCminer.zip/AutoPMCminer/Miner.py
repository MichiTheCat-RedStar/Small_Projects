import base64
import re
import time
from random import randint

money = 0
mined = 0
Save = open("Save.txt", "r", encoding="utf-8")

print("\nsystem/load> Введите код сохранения.")
UserAnswer = Save.read()
Save.close()
if UserAnswer == "U015XzgtUE1DLVNNZF8xMl9TUy0xLTE=":
    print("\nsystem/load> Предположитеьно что-то идёт не так.")
# U015XzY0MDgtUE1DLVNNZF8yOF9TUy0wLTA= - SMy_6408-PMC-SMd_28_SS-0-0
try:
    decodeBase = base64.b64decode(UserAnswer.encode('ascii')).decode('ascii')
    decodeTxt = re.findall(r"\D+", decodeBase)
    if (decodeTxt[0] == "SMy_") and (decodeTxt[1] == "-PMC-SMd_") and (decodeTxt[2] == "_SS-") and (decodeTxt[3] == "-"):
        decodeInt = re.findall(r"\d+", decodeBase)
        money = (int((int(decodeInt[0])-8)/16))/10
        mined = int((int(decodeInt[1])-12)/16)
        print("\nsystem/load> Успешно загружено.")
except Exception:
    print("\nsystem> Вы ввели код неверно и действие было отменено.")
    print("\nAutoMiner> У вас нет сохранения и будет создано новое.")
else:
    print("\nsystem> Вы ввели код неверно и действие было отменено.")
    print("\nAutoMiner> У вас нет сохранения и будет создано новое.")

print(f"\nAutoMiner> Денег: [{money}] и циклов: [{mined}].")

while True:

    TempNow = 0
    print("\nsystem/mine> Идёт поиск свободных циклов...")
    fat = bool(randint(0,1))
    if not fat:
        Temp = randint(3, 123)
    else:
        Temp = randint(1440, 5255)
    time.sleep(randint(5, 35)/10)
    print("system/mine> Цикл найден.")
    print("system/mine> Начинается вычисление...\n")
    time.sleep(randint(1, 15)/10)
    start = time.time()
    if not fat:
        while TempNow != Temp:
            print(f"system/mine> Решается... [{TempNow}/{Temp}]")
            TempNow += 1
            time.sleep(randint(10, 200)/100)
    else:
        while TempNow != Temp:
            print(f"system/mine> Решается... [{TempNow}/{Temp}]")
            TempNow += 1
            time.sleep(randint(5, 150)/1000)
    finish = time.time()
    if not fat:
        cash = randint(1, 50)/10
    else:
        cash = randint(25, 405)/10
    money += cash
    mined += 1
    OutTime = finish - start
    print(f"\nsystem/mine> Цикл выполнен! Заработано: {cash} PMC за {int(OutTime)} секунд")

    saved_money = int(((money * 10) * 16) + 8)
    saved_mined = int((mined * 16) + 12)
    code = f"SMy_{saved_money}-PMC-SMd_{saved_mined}_SS-0-0" # SavedMoney_{SMy}-PythonMinerCoins-SavedMined_{SMd}_SavedShop-{VIP}-{CFS}
    SaveText = str(base64.b64encode(code.encode('ascii')).decode('ascii'))

    Save = open("Save.txt", "w", encoding="utf-8")
    Save.write(SaveText)
    Save.close()

    print("\nAutoMiner> Произошло сохранение в файл.")
